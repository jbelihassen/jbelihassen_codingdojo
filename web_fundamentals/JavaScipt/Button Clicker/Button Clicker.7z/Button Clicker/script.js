// function logout
function logout(id){
    document.getElementById(id).innerText="logout"
}
// function hide
function hide(id){
     document.getElementById(id).remove()
}
// function aler
function aler(id){
     document.getElementById(id)
     alert("ninja was liked")
}
