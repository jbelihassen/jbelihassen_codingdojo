function like(id){
    document.getElementById(id).innerText++;
}